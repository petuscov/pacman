var http = require("http");
var fileSystem = require('fs');
var path = require('path');
/* Para jquery
let jsdom = require("jsdom");let $ = null;jsdom.env(...)$ = require('jquery')(window); 
//jquery necesita de un objeto window, en node no tenemos, hay que cargar una página cualquiera
//al final no usamos jquery, cargamos nivel 1.txt con el módulo fs.
*/
var express = require('express');
var app = express();
var serv = require('http').Server(app);

app.get('/css/index.css',function(req,res){
    res.sendFile(__dirname + '/css/index.css');   
});
app.get('/js/jquery-3.1.1.min.js',function(req,res){
    res.sendFile(__dirname + '/js/jquery-3.1.1.min.js');
});
app.get('/js/pacman.js',function(req,res){
    res.sendFile(__dirname + '/js/pacman.js');
});
app.get('/pacman.html',function(req,res){
    res.sendFile(__dirname + '/pacman.html'); 
});
app.get('/res/levels/1.txt',function(req,res){
    //console.log(req); Podemos ver la estructura del JSON del request.
    res.sendFile(__dirname + '/res/levels/1.txt'); 
});
app.get('/css/res/background.jpg',function(req,res){
    res.sendFile(__dirname + '/css/res/background.jpg');
});
app.get('/css/res/background.jpg',function(req,res){
    res.sendFile(__dirname + '/css/res/background.jpg'); 
});
app.get('/favicon.ico',function(req,res){
    res.sendFile(__dirname + '/res/pacman.ico');
});
app.get('/',function(req,res){
    res.sendFile(__dirname + '/main.html'); 
});
app.get('/pacman.html',function(req,res){
    res.sendFile(__dirname + '/main.html');
});
serv.listen(8888);
console.log("Server running (port 8888)...");

//Parte Servidor

var over;
var GLOBAL_TILE_SIDE = 20; //BALDOSAS CUADRADAS //se puede poner a 22,21,etc sin problemas //24
var GLOBAL_PACMAN_VEL = 3; //3
var GLOBAL_GHOST_HOME_RETURN_SPEED = 4; //4
var GLOBAL_GHOST_VULNERABLE_SPEED = 2; //2
var GLOBAL_GHOST_SPEED = 3; //3
var columnaPac; //MRs Pacman
var filaPac;
var columnaPacDos; //Pacman (2do player)
var filaPacDos;
var pelletsCargados;

var confirm = {};

var casaXBaldosa; //dentro de la casa de los fantasmas, baldosa, no coordenada.
var casaYBaldosa;
var numGhosts = 4;
var mapaEstrella = [];
var mapaPelletsCargados;

var thisLevel = null;
var ghosts = {};

var Ghost = function(id){

    this.x = 0;
    this.y = 0;
    this.velX = 0;
    this.velY = 0;
    this.state = Ghost.NORMAL;
    this.nearestRow = 0;
    this.nearestCol = 0;
    this.baldosaOrigenX;
    this.baldosaOrigenY;
    this.id = id;
    this.calcularPosiblesDirecciones = function(x,y){
        var posiblesDirecciones = [];
        if((x % thisGame.TILE_WIDTH) == 0 && (y % thisGame.TILE_HEIGHT) == 0){ //en baldosa exacta.
            if(!thisLevel.isWall(getRow(y),getCol(x-1))){
                tile = thisLevel.getMapTile(getRow(y),getCol(x-1));//
                if(tile!=20){// tile!=11 && ){ //11 se considera wall
                    posiblesDirecciones.push(0); //izquierda
                }
            }
            if(!thisLevel.isWall(getRow(y-1),getCol(x))){
                tile = thisLevel.getMapTile(getRow(y-1),getCol(x));
                if(tile!=21){
                    posiblesDirecciones.push(1); //arriba
                }
            }
            if(!thisLevel.isWall(getRow(y),getCol(x+thisGame.TILE_WIDTH))){
                tile = thisLevel.getMapTile(getRow(y),getCol(x+thisGame.TILE_WIDTH));
                if(tile!=20){ //&& tile!=13){ //13 se considera wall
                    posiblesDirecciones.push(2); //derecha
                }
            }
            if(!thisLevel.isWall(getRow(y+thisGame.TILE_HEIGHT),getCol(x))){
                tile = thisLevel.getMapTile(getRow(y+thisGame.TILE_HEIGHT),getCol(x));
                if(tile!=1 && tile!=21){
                    posiblesDirecciones.push(3); //abajo
                }else{
                    if(this.state==Ghost.SPECTACLES){posiblesDirecciones.push(3);}
                }
            }
        }
        return posiblesDirecciones;
    };
 
    this.movimientoEstrella = function(){
        var MAPWIDTH = thisLevel.lvlWidth;
        var MAPHEIGHT = thisLevel.lvlHeight;
        var BaldosaWidth = thisGame.TILE_WIDTH;
        var BaldosaHeight = thisGame.TILE_HEIGHT;
        var baldosaX = Math.floor(this.x/BaldosaWidth);
        var baldosaY = Math.floor(this.y/BaldosaHeight);

        var valorBaldosaFantasma = mapaEstrella[baldosaX+baldosaY*MAPWIDTH];
        var direccion = "";
        var direcciones = this.calcularPosiblesDirecciones(this.x,this.y);
        var encontrado = false;

        if(baldosaX==casaXBaldosa && baldosaY==casaYBaldosa){
            this.state = Ghost.NORMAL;

        }else{

            while(direcciones.length>0 && !encontrado){ 

                switch(direcciones[0]){
                    case 0: if(valorBaldosaFantasma>mapaEstrella[baldosaX-1+baldosaY*MAPWIDTH]){encontrado = true;direccion=0;}break; //izquierda
                    case 1: if(valorBaldosaFantasma>mapaEstrella[baldosaX+(baldosaY-1)*MAPWIDTH]){encontrado = true;direccion=1;}break; //arriba
                    case 2: if(valorBaldosaFantasma>mapaEstrella[baldosaX+1+baldosaY*MAPWIDTH]){encontrado = true;direccion=2;}break; //derecha
                    case 3: if(valorBaldosaFantasma>mapaEstrella[baldosaX+(baldosaY+1)*MAPWIDTH]){encontrado = true;direccion=3;}break; //abajo
                }
                direcciones.shift();
            }
            switch(direccion){
                case 0: this.velX = -GLOBAL_GHOST_HOME_RETURN_SPEED; this.velY = 0;this.x = this.x + this.velX;this.y = this.y + this.velY; break;
                case 1: this.velX = 0; this.velY = -GLOBAL_GHOST_HOME_RETURN_SPEED;this.x = this.x + this.velX;this.y = this.y + this.velY; break;
                case 2: this.velX = GLOBAL_GHOST_HOME_RETURN_SPEED; this.velY = 0;this.x = this.x + this.velX;this.y = this.y + this.velY; break;
                case 3: this.velX = 0; this.velY = GLOBAL_GHOST_HOME_RETURN_SPEED;this.x = this.x + this.velX;this.y = this.y + this.velY; break;
                default:{ //se entra aquí si el array con direcciones está vacio porque el fantasma no se encontraba EXACTAMENTE en una baldosa
                    nuevX = this.x + this.velX;nuevY = this.y + this.velY;
                    baldosaXNueva = Math.floor(nuevX/BaldosaWidth);
                    baldosaYNueva = Math.floor(nuevY/BaldosaHeight);
                    if(baldosaXNueva != baldosaX || baldosaYNueva!=baldosaY){ //al actualizar posición se cambiaria de casilla. ajustar EXACTA a la que deba ser.
                        if(this.velX > 0 || this.velY > 0){
                            this.x = baldosaXNueva*BaldosaWidth;
                            this.y = baldosaYNueva*BaldosaHeight;
                        }else{
                            if(this.velX < 0 || this.velY < 0){
                                this.x = baldosaX*BaldosaWidth;
                                this.y = baldosaY*BaldosaHeight;
                            }else{
                                console.log("comportamiento extraño");
                            }
                        }
                    }else{
                        this.x = nuevX;
                        this.y = nuevY; 
                    }
                    break;
                }
            }
        }
    }

    this.move = function() {
        var posiblesDirecciones;
        var direccion;
        // Si el estado del fantasma es Ghost.SPECTACLES el fantasma regresa a casa por el camino más corto
        if(this.state == Ghost.SPECTACLES){
            
            if(this.velX == this.velY){//para los tests.
                posiblesDirecciones = this.calcularPosiblesDirecciones(this.x,this.y);
                direccion = Math.floor(Math.random()*posiblesDirecciones.length); 
                switch(posiblesDirecciones[direccion]){
                    case 0: this.velX = -GLOBAL_GHOST_HOME_RETURN_SPEED; this.velY = 0; break;
                    case 1: this.velX = 0; this.velY = -GLOBAL_GHOST_HOME_RETURN_SPEED; break;
                    case 2: this.velX = GLOBAL_GHOST_HOME_RETURN_SPEED; this.velY = 0; break;
                    case 3: this.velX = 0; this.velY = GLOBAL_GHOST_HOME_RETURN_SPEED; break;
                }
            }
            this.movimientoEstrella();
        }else{

            
            if(this.x % thisGame.TILE_WIDTH == 0 && this.y % thisGame.TILE_HEIGHT == 0){ //en baldosa exacta.
                posiblesDirecciones = [];
                posiblesDirecciones=this.calcularPosiblesDirecciones(this.x,this.y);
                
                if( posiblesDirecciones.length>2){//si hay bifurcación
                    var previousDir;
                    var index;
                    if(this.velX < 0){
                        //previousDir=0; //izquierda
                        //quitamos el 2 del array de posibles direcciones si está.
                        index = posiblesDirecciones.indexOf(2);
                        if(index>-1){posiblesDirecciones.splice(index,1);}
                    }
                    if(this.velX > 0){
                        //previousDir=2; //derecha
                        //quitamos el 0 del array de posibles direcciones si está.
                        index = posiblesDirecciones.indexOf(0);
                        if(index>-1){posiblesDirecciones.splice(index,1);}
                    }
                    if(this.velY < 0){
                        //previousDir=1; //arriba 
                        //quitamos el 3 del array de posibles direcciones si está.
                        index = posiblesDirecciones.indexOf(3);
                        if(index>-1){posiblesDirecciones.splice(index,1);}
                    }
                    if(this.velY > 0){
                        //previousDir=3; //abajo
                        //quitamos el 1 del array de posibles direcciones si está.
                        index = posiblesDirecciones.indexOf(1);
                        if(index>-1){posiblesDirecciones.splice(index,1);}
                    }
                    direccion = Math.floor(Math.random()*posiblesDirecciones.length); 
                    switch(posiblesDirecciones[direccion]){
                        case 0: this.velX = -GLOBAL_GHOST_SPEED; this.velY = 0; break;
                        case 1: this.velX = 0; this.velY = -GLOBAL_GHOST_SPEED; break;
                        case 2: this.velX = GLOBAL_GHOST_SPEED; this.velY = 0; break;
                        case 3: this.velX = 0; this.velY = GLOBAL_GHOST_SPEED; break;
                    }
                }else{
                    var possiblePlayerX = this.x;
                    var possiblePlayerY = this.y;
                    if(this.velX < 0){
                        possiblePlayerX= this.x + this.velX;
                    }
                    if(this.velX > 0){
                        possiblePlayerX= this.x + this.velX + thisGame.TILE_WIDTH;
                    }
                    if(this.velY < 0){
                        possiblePlayerY = this.y + this.velY;
                    }
                    if(this.velY > 0){
                        possiblePlayerY = this.y + this.velY + thisGame.TILE_HEIGHT;
                    }
                    var columna = Math.floor(possiblePlayerX / thisGame.TILE_WIDTH);
                    var fila = Math.floor(possiblePlayerY / thisGame.TILE_HEIGHT);
                    var tile = thisLevel.getMapTile(fila,columna);
                    if(thisLevel.isWall(fila,columna) || tile ==20 || tile ==21){
                        direccion = Math.floor(Math.random()*posiblesDirecciones.length); 
                        switch(posiblesDirecciones[direccion]){
                            case 0: this.velX = -GLOBAL_GHOST_SPEED; this.velY = 0; break;
                            case 1: this.velX = 0; this.velY = -GLOBAL_GHOST_SPEED; break;
                            case 2: this.velX = GLOBAL_GHOST_SPEED; this.velY = 0; break;
                            case 3: this.velX = 0; this.velY = GLOBAL_GHOST_SPEED; break;
                        }
                    }
                }
                this.x = this.x + this.velX;
                this.y = this.y + this.velY;
            }else{ 
                //Si no se encuentra en baldosa exacta
                //Si el tamaño de la baldosa es p.e 24 la velocidad normal de los fantasmas debe ser multiplo de ese numero para todo ok
                //Por eso corregimos movimiento:
                
                var BaldosaWidth = thisGame.TILE_WIDTH;
                var BaldosaHeight = thisGame.TILE_HEIGHT;
                var baldosaX = Math.floor(this.x/BaldosaWidth);
                var baldosaY = Math.floor(this.y/BaldosaHeight);
                var nuevX = this.x + this.velX;
                var nuevY = this.y + this.velY;
                var baldosaXNueva = Math.floor(nuevX/BaldosaWidth);
                var baldosaYNueva = Math.floor(nuevY/BaldosaHeight);
                if(baldosaXNueva != baldosaX || baldosaYNueva!=baldosaY){ //al actualizar posición se cambiaria de casilla. ajustar EXACTA a la que deba ser.
                    if(this.velX > 0 || this.velY > 0){
                        this.x = baldosaXNueva*BaldosaWidth;
                        this.y = baldosaYNueva*BaldosaHeight;
                    }else{
                        if(this.velX < 0 || this.velY < 0){
                            this.x = baldosaX*BaldosaWidth;
                            this.y = baldosaY*BaldosaHeight;
                        }else{
                            console.log("comportamiento extraño");
                        }
                    }
                }else{
                    this.x = nuevX;
                    this.y = nuevY; 
                }
            }
        }
    };
}; // fin clase Ghost

// static variables
Ghost.NORMAL = 1;
Ghost.VULNERABLE = 2;
Ghost.SPECTACLES = 3;
var Level = function() {
    //this.ctx = ctx;
    this.lvlWidth = 0;
    this.lvlHeight = 0;
    this.map = [];
    this.pellets = 0;
    this.powerPelletBlinkTimer = 0;

    this.setMapTile = function(row, col, newValue){
        this.map[row*this.lvlWidth+col]=newValue;
    };

    this.getMapTile = function(row, col){   
        return this.map[row*this.lvlWidth+col]; 
    };

    this.printMap = function(){
        console.log(this.map);
    };

    this.loadLevel = function(){
        fileSystem.readFile(__dirname+"/res/levels/1.txt", function(err, f){ //dejamos de usar jquery en node.
            if(err!==null){console.log(err)};
            var lineas = f.toString().split('\n');
            var numFila = 0;
            var arrayFilas = [];
            for (i = 0; i < lineas.length; i++) {//Por cada linea
                elementosL = lineas[i].split(" ");
                
                if(elementosL[0] == "#"){
                    if(elementosL[1] == "lvlwidth"){thisLevel.lvlWidth=elementosL[2];} 
                    if(elementosL[1] == "lvlheight"){thisLevel.lvlHeight=elementosL[2];}
                }else if(elementosL[0]== ""){//para evitar interpretar lineas en blanco, se ignoran
                }else{
                    arrayFilas.push(elementosL);
                }
                
            } //codigo optimizado, antes era ineficiente.
            for(var numFila =0; numFila < arrayFilas.length; numFila++){
                for(j = 0; j < arrayFilas[0].length;j++){ //cojemos el 0 porque es irrelevante que fila coger puesto que tienen la misma longitud.
                    thisLevel.setMapTile((numFila),j,arrayFilas[numFila][j]);
                    if(arrayFilas[numFila][j] == "5"){
                        columnaPacDos= j;
                        filaPacDos = numFila;
                    }
                    if(arrayFilas[numFila][j] == "4"){
                        columnaPac= j;
                        filaPac = numFila;
                    }
                    if(arrayFilas[numFila][j] == "3"){
                        thisLevel.pellets+=1;
                    }
                    if(arrayFilas[numFila][j] == "2"){
                        thisLevel.pellets+=1;
                    }
                    //inicializamos posiciones origen fantasmas:
                    if(arrayFilas[numFila][j] == "10"){
                        ghosts[0].baldosaOrigenX = j;
                        ghosts[0].baldosaOrigenY = numFila;
                    }
                    if(arrayFilas[numFila][j] == "11"){
                        ghosts[1].baldosaOrigenX = j;
                        ghosts[1].baldosaOrigenY = numFila;
                    }
                    if(arrayFilas[numFila][j]== "12"){
                        ghosts[2].baldosaOrigenX = j;
                        ghosts[2].baldosaOrigenY = numFila;
                        casaXBaldosa = j; //inicializamos casilla "casa" de los fantasmas.
                        casaYBaldosa = numFila;
                    }
                    if(arrayFilas[numFila][j] == "13"){
                        ghosts[3].baldosaOrigenX = j;
                        ghosts[3].baldosaOrigenY = numFila;
                    }
                }
            }
            pelletsCargados = thisLevel.pellets;
            mapaPelletsCargados = thisLevel.map.slice();
            thisLevel.cargarMapaEstrella();
            //console.log("mapa cargado correctamente"+thisLevel.map);
        });
    };
    this.cargarMapaEstrella = function(){
        var MAPWIDTH = thisLevel.lvlWidth;
        var MAPHEIGHT = thisLevel.lvlHeight;
        var casillasAComprobar = [];
        var casillasVisitadas = thisLevel.map.slice(); //creamos copia
        for(var i=0;i<casillasVisitadas.length;i++){
            if(casillasVisitadas[i]<100 || mapaEstrella[i]>199){
                casillasVisitadas[i]=1; //las casillas que se pueden visitar a 1, las visitadas a 2.
            }else{
                casillasVisitadas[i]=-1; //ponemos -1 en las paredes.
            }
        }
        
        mapaEstrella = casillasVisitadas.slice(); //creamos copia

        mapaEstrella[casaXBaldosa + casaYBaldosa*MAPWIDTH] = 1; //la casa de los fantasmas tiene un valor de 1. (el más bajo)
        casillasVisitadas[casaXBaldosa + casaYBaldosa*MAPWIDTH] = 2;
        casillaInicial = casaXBaldosa + casaYBaldosa*MAPWIDTH;
        casillasAComprobar.push(casillaInicial);
        while(casillasAComprobar.length > 0){
            casillaAComprobar = casillasAComprobar.shift();
            valorCasilla = mapaEstrella[casillaAComprobar];
            //izquierda
            if(casillaAComprobar%MAPWIDTH!=0){ //si el resto es 0 no hay nada a la izquierda (borde del mapa)
                casIzRow = Math.floor(casillaAComprobar/MAPWIDTH);
                casIzCol = casillaAComprobar%MAPWIDTH-1;
                if(!this.isWall(casIzRow,casIzCol)){
                    if(casillasVisitadas[casIzCol+casIzRow*MAPWIDTH] != 2){
                        casillasAComprobar.push(casIzCol + casIzRow * MAPWIDTH);
                        mapaEstrella[casIzCol + casIzRow * MAPWIDTH] = valorCasilla+1;
                        casillasVisitadas[casIzCol + casIzRow * MAPWIDTH] = 2;
                    }
                }
            }
            //derecha 
            if(casillaAComprobar%MAPWIDTH!=MAPWIDTH-1){ //si el resto es igual al ancho del mapa no hay nada a la derecha(borde del mapa)
                casIzRow = Math.floor(casillaAComprobar/MAPWIDTH);
                casIzCol = casillaAComprobar%MAPWIDTH+1;
                if(!this.isWall(casIzRow,casIzCol)){
                    if(casillasVisitadas[casIzCol+casIzRow*MAPWIDTH] != 2){
                        casillasAComprobar.push(casIzCol + casIzRow * MAPWIDTH);
                        mapaEstrella[casIzCol + casIzRow * MAPWIDTH] = valorCasilla+1;
                        casillasVisitadas[casIzCol + casIzRow * MAPWIDTH] = 2;
                    }
                }
            }
            //arriba
            if(Math.floor(casillaAComprobar/MAPWIDTH)!=0){ //si la división es 0 no hay nada arriba (borde del mapa)
                casIzRow = Math.floor(casillaAComprobar/MAPWIDTH)-1;
                casIzCol = casillaAComprobar%MAPWIDTH;
                if(!this.isWall(casIzRow,casIzCol)){
                    if(casillasVisitadas[casIzCol+casIzRow*MAPWIDTH] != 2){
                        casillasAComprobar.push(casIzCol + casIzRow * MAPWIDTH);
                        mapaEstrella[casIzCol + casIzRow * MAPWIDTH] = valorCasilla+1;
                        casillasVisitadas[casIzCol + casIzRow * MAPWIDTH] = 2;
                    }
                }
            }
            //abajo
            if(Math.floor(casillaAComprobar/MAPWIDTH)!=MAPHEIGHT-1){ //si la división es igual a la altura no hay nada debajo (borde del mapa)
                casIzRow = Math.floor(casillaAComprobar/MAPWIDTH)+1;
                casIzCol = casillaAComprobar%MAPWIDTH;
                if(!this.isWall(casIzRow,casIzCol)){
                    if(casillasVisitadas[casIzCol+casIzRow*MAPWIDTH] != 2){
                        casillasAComprobar.push(casIzCol + casIzRow * MAPWIDTH);
                        mapaEstrella[casIzCol + casIzRow * MAPWIDTH] = valorCasilla+1;
                        casillasVisitadas[casIzCol + casIzRow * MAPWIDTH] = 2;
                    }
                }
            }
        }
       //tenemos en mapaEstrella el mapa estrella hasta casa de los fantasmas.
        //for(var j =0;j<MAPHEIGHT;j++){
        //  fila = "";
        //  for(var i=0;i<MAPWIDTH;i++){
        //      fila = fila + mapaEstrella[j*MAPWIDTH+i] +" ";
        //  }
        //  console.log(fila);
        //}
    }
    
    this.isWall = function(row, col) { 
        var tile = thisLevel.getMapTile(row,col);
        tile = parseInt(tile, 10);
        var wall = false;
        if(tile>=100 && tile <=199){
            wall = true;
        }
        //if(isNaN(tile)){//fuera del mapa (No nos es necesario)
        //  wall=true;
        //}
        if(tile==11||tile==13){
            wall=true;
        }
        return wall;
    };


    this.checkIfHitWall = function(possiblePlayerX, possiblePlayerY, row, col){
        // Determinar si el jugador va a moverse a una fila,columna que tiene pared 
        var colision = false;
        //se comprueba si hay colisión al moverse normalmente, movimiento rectilíneo uniforme, sin pulsar tecla
        if(row == null && col == null){ 
            columna = Math.floor(possiblePlayerX / thisGame.TILE_WIDTH);
            fila = Math.floor(possiblePlayerY / thisGame.TILE_HEIGHT);
            if(thisLevel.isWall(fila,columna)){
                colision = true;
            }
        }else{
            //codigo para mirar si hay colision al pulsar tecla, row y col solo se pasan si se pulsa tecla
            
            columna = Math.floor(possiblePlayerX / thisGame.TILE_WIDTH); 
            fila = Math.floor(possiblePlayerY / thisGame.TILE_HEIGHT);

            if(thisLevel.isWall(fila,columna)){
                colision = true;
            }else{
                if(columna == col){ //pacman moviendose en eje vertical y se pulsa tecla arriba ó abajo.
                    if(possiblePlayerX!=col*thisGame.TILE_WIDTH){//si las coordenadas de la columna a la que se entra no coinciden exactamente colisión.
                        colision = true;
                    }
                }else{  
                    if(fila == row){  //pacman moviendose en eje horizontal y se pulsa tecla derecha o izquierda.
                        if(possiblePlayerY!=row*thisGame.TILE_HEIGHT){//si las coordenadas de la fila a la que se entra no coinciden exactamente colisión.
                            colision = true;
                        }
                    }else{  
                        console.log("comportamiento inesperado");
                        console.log(possiblePlayerX +" , "+possiblePlayerY);
                    }

                }
            }
        }
        //Colision con fantasmas se mira en método move.
        return colision;  
    };

    this.checkIfHit = function(playerX, playerY, x, y, holgura){
        // Tu código aquí   
        var proyeccionX = false;
        var proyeccionY = false;
        var hit = false;
        if(Math.abs(playerX - x)<holgura){
            proyeccionX = true;
        }   
        if(Math.abs(playerY - y)<holgura){
            proyeccionY = true;
        }
        if(proyeccionY && proyeccionX){hit = true;}
        return hit; 
    };


    this.checkIfHitSomething = function(playerX, playerY, row, col,playerId){
        var tileID = {
            'door-h' : 20,
            'door-v' : 21,
            'pellet-power' : 3,
            'pellet': 2
        };

        //  Gestiona la recogida de píldoras
        columna = Math.floor(playerX / thisGame.TILE_WIDTH); 
        fila = Math.floor(playerY / thisGame.TILE_HEIGHT);
        //No se hace USO DE ROW Y COL
        if(columna==playerX / thisGame.TILE_WIDTH && fila==playerY / thisGame.TILE_HEIGHT){

            if(thisLevel.getMapTile(fila,columna)=="2"){ 
                thisLevel.setMapTile(fila,columna,"0");
                pelletComido(fila,columna);//Informamos a los sockets que están conectados.
                thisLevel.pellets-=1; 
                listaPlayers[playerId].points+=10;
                
                if(thisLevel.pellets == 0){
                    thisGame.modeTimer = 90;//se podría incluir en passLevel TODO
                    passLevel();
                    thisGame.setMode(thisGame.WAIT_TO_START);//se podría incluir en passLevel TODO

                }
            }
        }

        //  Gestiona las puertas teletransportadoras
        if(thisLevel.getMapTile(fila,columna)=="20"){ //|| thisLevel.getMapTile(fila,columna+1)=="20"){  // || para detectar antes puerta lateral derecha. (y pasar el test.)
            if(columna==playerX / thisGame.TILE_WIDTH && fila==playerY / thisGame.TILE_HEIGHT){
                if(getCol(playerX)==0){//"teletransporte" de izquierda a derecha
                    listaPlayers[playerId].x = thisLevel.lvlWidth * thisGame.TILE_WIDTH-1-2*thisGame.TILE_WIDTH; //2* para evitar bucle debido a detectar antes puerta lateral derecha.
                    listaPlayers[playerId].velX = -GLOBAL_PACMAN_VEL;
                }else{//"teletransporte" de derecha a izquierda
                    listaPlayers[playerId].x = 1+thisGame.TILE_WIDTH;
                    listaPlayers[playerId].velX = GLOBAL_PACMAN_VEL;
                }
            }
            
        }
        if(thisLevel.getMapTile(fila,columna)=="21"){//|| thisLevel.getMapTile(fila+1,columna)=="21"){ // || para detectar antes puerta inferior. (y pasar el test.)
            if(columna==playerX / thisGame.TILE_WIDTH && fila==playerY / thisGame.TILE_HEIGHT){
                if(getRow(playerY)==0){//"teletransporte" de arriba a abajo
                    listaPlayers[playerId].y = thisLevel.lvlHeight* thisGame.TILE_HEIGHT-1-2*thisGame.TILE_HEIGHT; //2* para evitar bucle debido a detectar antes puerta inferior.
                    listaPlayers[playerId].velY = -GLOBAL_PACMAN_VEL;
                }else{//"teletransporte" de abajo a arriba

                    listaPlayers[playerId].y = 1+thisGame.TILE_HEIGHT;
                    listaPlayers[playerId].velY = GLOBAL_PACMAN_VEL;
                }
            }
        }
        // Gestionamos la recogida de píldoras de poder (cambiamos estado de los fantasmas)
        if(thisLevel.getMapTile(fila,columna)=="3"){ 

            thisLevel.setMapTile(fila,columna,"0");
            pelletComido(fila,columna);//Informamos a los sockets que están conectados.

            thisLevel.pellets-=1; //Contamos también las pildoras de poder
            listaPlayers[playerId].points+=10;
            
            if(thisLevel.pellets == 0){
                thisGame.modeTimer = 90;//se podría incluir en passLevel TODO
                passLevel();
                thisGame.setMode(thisGame.WAIT_TO_START);//se podría incluir en passLevel TODO
            }
            thisGame.ghostTimer = 360;
            for(var i=0;i<numGhosts;i++){
                if (ghosts[i].state == Ghost.NORMAL){
                    ghosts[i].state = Ghost.VULNERABLE;
                }
                
            }
        }
    };
    this.mapaBordes =function(){
        map = [];
        for(var i=0;i<thisLevel.lvlWidth;i++){ //borde superior
            map.push(100);
        }
        for(var i=1;i<thisLevel.lvlHeight-1;i++){
            map.push(100);
            for(var j=1;j<thisLevel.lvlWidth-1;j++){
                map.push(0);
            }
            map.push(100);
        }
        for(var i=0;i<thisLevel.lvlWidth;i++){ //borde inferior
            map.push(100);
        }
        return map;
    }
    this.processGameOver = function(){ //separar parte calculo posicion fantasmas de dibujado para cliente-servidor
        if(!over){
            over = true;
            thisLevel.map = this.mapaBordes();
            for(var i =0;i<numGhosts;i++){
                ghosts[i].velX=0;
                ghosts[i].velY=-GLOBAL_GHOST_SPEED; //hacia arriba
                ghosts[i].x=ghosts[i].baldosaOrigenX*thisGame.TILE_WIDTH;
                ghosts[i].y=ghosts[i].baldosaOrigenY*thisGame.TILE_HEIGHT;
                ghosts[i].state = Ghost.NORMAL;
            }
            thisGame.ghostTimer = 0;
        }
        for(var i=0;i<numGhosts;i++){
            ghosts[i].move();
        }
    }
};

var Pacman = function(id) {
    //this.radius = GLOBAL_TILE_SIDE/2-2;
    this.x = 0;
    this.y = 0;
    //this.angle1 = 0.25;
    //this.angle2 = 1.75;
    this.velX;
    this.velY;
    this.lastDirection = id==0 ? 1 : 3;
    this.id = id;
    this.name = id; //de momento
    this.lifes =3;
    this.points =0;
};
Pacman.prototype.move = function() {

    var BaldosaWidth = thisGame.TILE_WIDTH;
    var BaldosaHeight = thisGame.TILE_HEIGHT;
    var baldosaX = Math.floor(this.x/BaldosaWidth);
    var baldosaY = Math.floor(this.y/BaldosaHeight);
    var balExacta = false;
    if(baldosaX == this.x/BaldosaWidth && baldosaY == this.y/BaldosaHeight){
        balExacta = true;
    }
    if(this.velX!=0||this.velY!=0){ 
        if(this.velX<0){
            this.lastDirection=1;
        }else{
            if(this.velX>0){
                this.lastDirection=3;
            }else{
                if(this.velY>0){
                    this.lastDirection=2;
                }else{
                    this.lastDirection=0;
                }
            } 
        }
    }
    //corregir movimientos izquierda arriba que hacen que se pare, y que se pare.
    if(this.velX>0){ 
        if(thisLevel.checkIfHitWall(this.x+thisGame.TILE_WIDTH+this.velX,this.y)){
            this.velX=0;
            this.velY=0; //opcional, pero evita posibles complicaciones 
            var tilePreWallX = Math.floor((this.x+thisGame.TILE_WIDTH+this.velX)/thisGame.TILE_WIDTH)*thisGame.TILE_WIDTH; //que se pegue a la pared.
            this.x = tilePreWallX; 
        }else{
            this.x=this.x+this.velX;
        }
    }else if(this.velX<0){
        if(thisLevel.checkIfHitWall(this.x+this.velX,this.y)){
            this.velX=0;
            this.velY=0; //opcional, pero evita posibles complicaciones 
            var tilePreWallX = Math.floor((this.x+this.velX)/thisGame.TILE_WIDTH)*thisGame.TILE_WIDTH; //que se pegue a la pared.
            this.x = tilePreWallX; 
        }else{
            this.x=this.x+this.velX;
        }
    }

    //EJE Y
    if(this.velY>0){
        if(thisLevel.checkIfHitWall(this.x,this.y+thisGame.TILE_HEIGHT+this.velY)){
            this.velY=0;
            this.velX=0; //opcional, pero evita posibles complicaciones 
            var tilePreWallY = Math.floor((this.y+thisGame.TILE_HEIGHT+this.velY)/thisGame.TILE_HEIGHT)*thisGame.TILE_HEIGHT; //que se pegue a la pared.
            this.y = tilePreWallY; 
        }else{
            this.y=this.y+this.velY;
        }
    }else if(this.velY<0){
        if(thisLevel.checkIfHitWall(this.x,this.y+this.velY)){
            this.velY=0;
            this.velX=0; //opcional, pero evita posibles complicaciones 
            var tilePreWallY = Math.floor((this.y+this.velY)/thisGame.TILE_HEIGHT)*thisGame.TILE_HEIGHT; //que se pegue a la pared.
            this.y = tilePreWallY; 
        }else{
            this.y=this.y+this.velY;
        }
    }

    //Esto puede parecer redundante pero corrige fallos en movimiento al cambiar tamaño de baldosa del mapa.
    //Se ha hecho igual en movimiento fantasmas.
    var baldosaXNueva = Math.floor(this.x/BaldosaWidth);
    var baldosaYNueva = Math.floor(this.y/BaldosaHeight);
    if( (baldosaXNueva != baldosaX || baldosaYNueva!=baldosaY) && !balExacta){ //al actualizar posición se cambiaria de casilla. ajustar EXACTA a la que deba ser.
        if(this.velX > 0 || this.velY > 0){
            this.x = baldosaXNueva*BaldosaWidth;
            this.y = baldosaYNueva*BaldosaHeight;
        }else{
            if(this.velX < 0 || this.velY < 0){
                this.x = baldosaX*BaldosaWidth;
                this.y = baldosaY*BaldosaHeight;
            }
        }
    }



    // tras actualizar this.x  y  this.y... 
    // check for collisions with other tiles (pellets, etc)
    thisLevel.checkIfHitSomething(this.x, this.y, this.nearestRow, this.nearestCol, this.id);
    //Si chocamos contra un fantasma y su estado es Ghost.VULNERABLE cambiamos velocidad fantasma y lo pasamos a modo Ghost.SPECTACLES
    for(var i =0;i<numGhosts;i++){ //comprobamos si hay contacto con los fantasmas.
        if(thisLevel.checkIfHit(this.x,this.y,ghosts[i].x,ghosts[i].y,thisGame.TILE_WIDTH/2)){
            if(ghosts[i].state == Ghost.VULNERABLE){
                ghosts[i].state = Ghost.SPECTACLES;
                if(ghosts[i].velX > 0 ){//actualizamos velocidad X fantasma.
                    ghosts[i].velX = GLOBAL_GHOST_VULNERABLE_SPEED;
                }else{
                    if(ghosts[i].velX < 0){
                        ghosts[i].velX = -GLOBAL_GHOST_VULNERABLE_SPEED;
                    }
                }
                if(ghosts[i].velY > 0 ){//actualizamos velocidad Y fantasma.
                    ghosts[i].velY = GLOBAL_GHOST_VULNERABLE_SPEED;
                }else{
                    if(ghosts[i].velY < 0){
                        ghosts[i].velY = -GLOBAL_GHOST_VULNERABLE_SPEED;
                    }
                }
            }else{
                if(ghosts[i].state == Ghost.NORMAL){
                    if(thisGame.mode != thisGame.HIT_GHOST){
                        // Si chocamos contra un fantasma cuando éste esta en estado Ghost.NORMAL --> cambiar el modo de juego a HIT_GHOST
                        thisGame.setMode(thisGame.HIT_GHOST);
                        if(thisLevel.pellets>0){
                            this.lifes--;
                            
                        }
                        informarVidaAct(this.id);
                        //lifesContainer.innerHTML = "Vidas: "+this.lifes;
                        //console.log("player " + this.id + "ha perdido 1 vida, restantes " + this.lifes);

                    }
                    
                }
            }
        }
        
    }
};

var thisGame = {
    getLevelNum : function(){
        return 0;
    },
    setMode : function(mode) {
        this.mode = mode;
        if(mode == thisGame.HIT_GHOST){
            thisGame.modeTimer = 90; //90 Frames, 1,5 segundos.

            //congelado = false;
        }
    },
    TILE_WIDTH: GLOBAL_TILE_SIDE, 
    TILE_HEIGHT: GLOBAL_TILE_SIDE,
    ghostTimer: 0,
    NORMAL : 1,
    HIT_GHOST : 2,
    GAME_OVER : 3,
    WAIT_TO_START: 4,
    MENSAJES: 5,
    //FROZEN: 5,

    modeTimer: 0,
    pantalla: undefined,
    //congelado: false
};




var getRow = function(y){
    return Math.floor(y/thisGame.TILE_HEIGHT);
}

var getCol = function(x){
    return Math.floor(x/thisGame.TILE_WIDTH);
}

var checkInputs = function(){
    //row y col para mirar si se entra demasiado pronto o demasiado tarde por pasillo lateral.
    var velocidadPosible = GLOBAL_PACMAN_VEL;
    for(var i=0;i<2;i++){
        var player = listaPlayers[i];
        var inputStates = inputStatesPlayer[i];

        if(inputStates["up"] == true){ //miramos si en el lugar donde se va a mover hay muro.
            if(!thisLevel.checkIfHitWall(player.x,player.y-velocidadPosible,getRow(player.y),getCol(player.x))){
                player.velY = -velocidadPosible;
                player.velX = 0;
            }
        }
        if(inputStates["down"] == true){
            if(!thisLevel.checkIfHitWall(player.x,player.y+thisGame.TILE_HEIGHT+velocidadPosible,getRow(player.y),getCol(player.x))){
                if(thisLevel.getMapTile(getRow(player.y+thisGame.TILE_HEIGHT),getCol(player.x))!=1){
                    player.velY = velocidadPosible;
                    player.velX = 0;
                }
                
            }
        }
        if(inputStates["left"] == true){
            if(!thisLevel.checkIfHitWall(player.x-velocidadPosible,player.y,getRow(player.y),getCol(player.x))){
                player.velX = -velocidadPosible;
                player.velY = 0;
            }
        }
        if(inputStates["right"] == true){
            if(!thisLevel.checkIfHitWall(player.x+thisGame.TILE_WIDTH+velocidadPosible,player.y,getRow(player.y),getCol(player.x))){
                player.velX = +velocidadPosible;
                player.velY = 0;
            }
        }
        if(inputStates["espacio"] == true){//"espacio" in inputStates){
            
            if(thisGame.mode == thisGame.GAME_OVER || thisGame.mode == thisGame.MENSAJES){
                
                //thisGame.state = thisGame.WAIT_TO_START;
                //thisGame.modeTimer = 90; 
                
                if(Object.getOwnPropertyNames(confirm).length == 0){ 
                    //para que ambos jugadores estén de acuerdo en jugar otra partida al pulsar espacio uno de ellos.

                    confirm.accepta1 = i; // se guarda el id del primero que acepta. (el que quiere volver a jugar)
                    /*enviar info a ambos (al que quiere volver a jugar de "esperando respuesta jugador 2",
                     y al otro: "jugador 2 quiere volver a jugar") (para ambos el jugador 2 es el otro)*/
                    var otro = i==0 ? 1:0;
                    emitirMensajesOtraPartida(i,otro);
                }else{

                    if(confirm.accepta1 != i){ //esto quiere decir que el que ha pulsado espacio es el otro player (el que falta).
                        
                        confirm = {};
                        passLevel();
                        partida(); //no es necesario método emit("partida",{}), se envia continuamente estado a clientes.
                        
                    }
                }
            }
          //inputStates = {};
        }
    }
};
var updateTimers = function(){
    // Actualizamos thisGame.ghostTimer (y el estado de los fantasmas)
    if(thisGame.ghostTimer>0){ 
        thisGame.ghostTimer--;
        if(thisGame.ghostTimer==0){
            for(var i=0;i<numGhosts;i++){
                if(ghosts[i].state == Ghost.VULNERABLE){
                    ghosts[i].state = Ghost.NORMAL;
                }
            }
        }
    }
    // actualizamos modeTimer
     if(thisGame.modeTimer>0){ 
        if(thisGame.modeTimer==1){
            //thisGame.congelado = false;
            //reset();
            thisGame.setMode(thisGame.NORMAL);
        }else{
            if(thisGame.modeTimer==31){ //30Frames, 0,5 Segundos
                //thisGame.congelado = false;
                


                reset();
                thisGame.setMode(thisGame.WAIT_TO_START);
               
            }
        }
        thisGame.modeTimer--;
    }
    //if(thisGame.ghostTimer==0){

    //}
};

var mainLoop = function(){ //SEPARAMOS PARTES DE CALCULO Y DE DIBUJADO PARA SERVIDOR -CLIENTE 
    setInterval(function(){

        //en modo NORMAL
        if(thisGame.mode == thisGame.NORMAL){ 
            
            //readInputs();de manera asincrona con eventos.
            // Movemos fantasmas
            for(var i=0;i<numGhosts;i++){
                ghosts[i].move();
            }
            listaPlayers[0].move();
            listaPlayers[1].move();
        }
        //en modo HIT_GHOST
        if(thisGame.mode == thisGame.HIT_GHOST){ //pantalla frozen.
            //se debería quedar todo parado durande 1.5 segs. (no actualizamos posiciones de nadie).
        }
        //en modo WAIT_TO_START
        if(thisGame.mode == thisGame.WAIT_TO_START){
            
            //se debería mostrar el pacman en su casilla de inicio y los fantasmas en sus posiciones y todo parado durande medio seg.
            //if(thisGame.congelado == false){

                if(listaPlayers[0].lifes==0||listaPlayers[1].lifes==0){
                    thisGame.setMode(thisGame.GAME_OVER);
                }//else{
                  
                    //thisLevel.preDrawMap();
                    
            //        thisGame.congelado = true;
            //    }
            //}
          
        }
       

        checkInputs();

        if(thisGame.mode == thisGame.GAME_OVER){ 
            
            //console.log("uno de los dos jugadores ha perdido todas sus vidas. GameOver"); Mostrar el mensaje solo 1 vez..
            //process.exit();//Apagar el servidor.

            thisLevel.processGameOver();//mostramos puntuacion de jugador(es)
            

        }else{
            if(thisGame.mode != thisGame.MENSAJES){
                 updateTimers(); //si se hace update timers cuando está en modo mensajes se vuelve al modo normal.
            }
        }
        // call the animation loop every 1/60th of second

        sendInfoToSockets();

        //requestAnimationFrame(mainLoop);
        //mainLoop();
    }, 1000/60);
};


 var reset = function(){ //al comenzar nueva vida
    // Inicialmente Pacman se mueve en horizontal hacia la derecha

    listaPlayers[0].x = columnaPac*thisGame.TILE_WIDTH;
    listaPlayers[0].y = filaPac*thisGame.TILE_HEIGHT;

    listaPlayers[1].x = columnaPacDos*thisGame.TILE_WIDTH;
    listaPlayers[1].y = filaPacDos*thisGame.TILE_HEIGHT;

    inputStatesPlayer[0] = {};
    inputStatesPlayer[1] = {};
    listaPlayers[0].velY = 0;
    listaPlayers[0].velX = -GLOBAL_PACMAN_VEL;
    listaPlayers[0].lastDirection = 1;

    listaPlayers[1].velY = 0;
    listaPlayers[1].velX = GLOBAL_PACMAN_VEL;
    listaPlayers[1].lastDirection = 3;
    // Inicializamos los atributos x,y, velX, velY de los fantasmas de forma conveniente
    for(var i =0;i<numGhosts;i++){
        ghosts[i].velX=0;
        ghosts[i].velY=-GLOBAL_GHOST_SPEED; //hacia arriba
        ghosts[i].x=ghosts[i].baldosaOrigenX*thisGame.TILE_WIDTH;
        ghosts[i].y=ghosts[i].baldosaOrigenY*thisGame.TILE_HEIGHT;
        ghosts[i].state = Ghost.NORMAL;
    }
    thisGame.ghostTimer = 0;
   
};

var passLevel = function(){ //al pasar de nivel (inicialización pellets)
    thisLevel.map = mapaPelletsCargados.slice(); //en la primera ejecucion no es necesario, pero si se reinicia la partida si (o si se pasa nivel)
    thisLevel.pellets = pelletsCargados;
    reinicioMapClients();
}


var partida = function(){ //al comenzar partida
    thisGame.setMode(thisGame.WAIT_TO_START); 
    thisGame.modeTimer = 30; 
    over = false;
    listaPlayers[0].points=0;
    listaPlayers[1].points=0;
    reset();
    listaPlayers[0].lifes=3;
    listaPlayers[1].lifes=3;

    informarVidaAct(0); //informamos player0 de que tiene 3 vidas (en cliente en 1ra ejecución no es necesario, pero al reiniciar si).
    informarVidaAct(1); // //.

    //passLevel(); //mapa ya está incializado correctamente en la 1ra ejecución, y el nro de pellets tambien.

}
var init = function(){ //al iniciar server.
    thisLevel = new Level();
    for (var i=0; i< numGhosts; i++){
        ghosts[i] = new Ghost(i);
    }
    thisLevel.loadLevel( thisGame.getLevelNum() );
}


var start = function(){ //al conectarse 2do jugador
    
    reloj = setTimeout(function esperarCargaMapaYLecturaPosPacman(){
        
        partida();

        // start the animation
        //requestAnimationFrame(mainLoop);
        mainLoop();

    }, 500); 
}



var listaPlayers = [];//jugadores
var inputStatesPlayer = [];
var player1 = new Pacman(0);
var player2 = new Pacman(1);
listaPlayers.push(player1);
listaPlayers.push(player2);
init(); //el cargado del mapa es asíncrono.


//////WS

var listaConectados = [];//sockets

//inputStates = {};

var io=require('socket.io')(serv,{});

io.sockets.on('connection',function(socket){

    listaConectados.push(socket);//no la estamos usando para nada, igual es más conveniente que el uso de io.emit

    console.log("socket connection, " +listaConectados.length+ " sockets on line");

    

    if(listaConectados.length<3){//sólo pueden jugar 2 simultáneamente.

        socket.emit("idPlayer",{
            "user":listaConectados.length-1,
        }); //se asigna id al socket que se acaba de conectar
        socket.emit("serverWantsName",{//no necesitamos enviar parametros adicionales
        }); 

        if(listaConectados.length==2){

            io.emit("start",{//no necesitamos enviar parametros adicionales
            }); 

            start();//COMENZAR PARTIDA
        }
        if(listaConectados.length==1){
            thisGame.setMode(thisGame.MENSAJES);
            socket.emit("waitingStart",{mensaje: "Esperando conexión jugador 2...",modo: thisGame.mode});
            
        }
    }else{
        //Codigo para espectadores.
        socket.emit("start",{//no necesitamos enviar parametros adicionales
            "listaPlayers":listaPlayers
        }); 
        io.emit("serverInfoNames",{ 
            "name1":player1.name,
            "name2":player2.name
        });
        /*para informar a los espectadores de como está el mapa en el momento
        en el que se conectan y para resetearlo al pasar nivel o reiniciar juego*/
        socket.emit("estadoMapa",{ 
            "mapa":thisLevel.map
        });
    }

    socket.on('userName',function(data){

        if(data.idPlayer ==0){
            player1.name = data.name;
        }else{
            player2.name = data.name;
            //Si el id del user es 1 es el segundo usuario conectado, se les puede informar a ambos del nombre del otro.
            io.emit("serverInfoNames",{
                "name1":player1.name,
                "name2":player2.name
            });
        }
    });

    socket.on('input',function(data){//no es necesario pasar el idPlayer, podríamos identificarlo por el socket.
        inputStatesPlayer[data.idPlayer] = data.inputStates;
    });

    socket.on('disconnect', function() {
        var user = socket.request.connection.remoteAddress;
        //console.log(user +' Got disconnect!');
        pos = listaConectados.indexOf(socket);
        listaConectados.splice(pos, 1);
        if(pos==0 ||pos==1){
            console.log("one of the players disconected. Game must be killed.");
            //paramos el juego (matarlo, no vamos a implementar reconexión.)
            thisGame.setMode(thisGame.MENSAJES);
            io.emit("waitingScreen",{mensaje: "Un jugador se ha desconectado. \n Game must be killed."});
            setTimeout(function err(){
                throw "juegoFinalizado";
            }, 100); //para que se emita el evento. Si no se espera un poco no se muestra la pantalla correspondiente en el cliente.
        }
        console.log("socket disconection, " +listaConectados.length+ " sockets on line");

    });

} );



emitirMensajesOtraPartida = function(idWant, idMust){ //idWant = el que quiere repetir, idMust = el que debe responder.
    listaConectados[idWant].emit("waitingScreen",{mensaje: "Esperando respuesta del jugador 2..."});
    listaConectados[idMust].emit("waitingScreen",{mensaje: "Jugador 2 quiere volver a jugar... \n Pulsa espacio para aceptar."});
    thisGame.setMode(thisGame.MENSAJES);
}



reinicioMapClients = function(){ //IMPORTANTE. los 2 primeros sockets son los players. 
    var players = listaConectados.slice(0,2);
    players[0].emit("serverMapReestart",{});
    players[1].emit("serverMapReestart",{});
    
}

informarVidaAct = function(id){
    listaConectados[id].emit("vidasActuales",{"vidas": listaPlayers[id].lifes});
}

//informarPtos = function(id){ //Necesario o los informamos continuamente?
//    listaConectados[id].emit("puntosActuales",{"puntos": listaPlayers[id].points});
//}

pelletComido = function(row,col){
    
    io.emit("pelletComido",{ 
        "fila":row,
        "columna":col
    });
}

sendInfoToSockets = function(){ /*inGame, se envia info de ambos users (pos,vel,state,points), de fantasmas, estado juego 

    NO->¿mapa?¿Pellets comidos? si se envia mapa continuamente igual hay sobrecarga o es ineficiente, si no se hace hay que
    añadir lógica en cliente para borrar pellets... (no es elegante...). 
    (se puede poner null cuando no haya cambios e informar cuando se cambie un pellet...)

    EL MAPA lo actualizaremos (los pellets) mediante eventos, cuando se coma un pellet se informará a los sockets conectados con la fila y la columna.
    */

    /*Enviar mapa cuando se conecte un socket para que lo tenga actualizado.*/
    var playUnoX = listaPlayers[0].x;
    var playUnoY = listaPlayers[0].y;
    var playUnoVelX = listaPlayers[0].velX;
    var playUnoVelY = listaPlayers[0].velY;
    var playUnoPoints = listaPlayers[0].points;
    var lastDirUno = listaPlayers[0].lastDirection;

    var playDosX = listaPlayers[1].x;
    var playDosY = listaPlayers[1].y;
    var playDosVelX = listaPlayers[1].velX;
    var playDosVelY = listaPlayers[1].velY;
    var playDosPoints = listaPlayers[1].points;
    var lastDirDos = listaPlayers[1].lastDirection;

    var ghostUnoX = ghosts[0].x;
    var ghostUnoY = ghosts[0].y;
    var ghostUnoSt = ghosts[0].state;
    var ghostDosX = ghosts[1].x;
    var ghostDosY = ghosts[1].y;
    var ghostDosSt = ghosts[1].state;
    var ghostTresX = ghosts[2].x;
    var ghostTresY = ghosts[2].y;
    var ghostTresSt = ghosts[2].state;
    var ghostCuaX = ghosts[3].x;
    var ghostCuaY = ghosts[3].y;
    var ghostCuaSt = ghosts[3].state;
    io.emit("it",{ //it de iteración
        "player1": {"x": playUnoX,
                    "y": playUnoY,
                    "velX": playUnoVelX,
                    "velY": playUnoVelY,
                    "points": playUnoPoints,
                    "ld":lastDirUno
                },  
        "player2": {"x": playDosX,
                    "y": playDosY,
                    "velX": playDosVelX,
                    "velY": playDosVelY,
                    "points": playDosPoints,
                    "ld":lastDirDos
                },  
        //lifes se informan cuando haya cambio, id,name 1 vez al conectarse.
        "ghosts":{
            "uno": {"x":ghostUnoX,"y":ghostUnoY,"st":ghostUnoSt},
            "dos": {"x":ghostDosX,"y":ghostDosY,"st":ghostDosSt},
            "tres": {"x":ghostTresX,"y":ghostTresY,"st":ghostTresSt},
            "cuatro": {"x":ghostCuaX,"y":ghostCuaY,"st":ghostCuaSt},
        },
        //"map":thisLevel.map,
        "mode":thisGame.mode,
        "ghostTimer":thisGame.ghostTimer
     });
}

